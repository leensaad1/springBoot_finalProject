package com.example.springboot_finalproject.Service;

import com.example.springboot_finalproject.Exception.ApiException;
import com.example.springboot_finalproject.Model.Doctor;
import com.example.springboot_finalproject.Model.Patient;
import com.example.springboot_finalproject.Repository.PatientRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PatientService {

    final private PatientRepository patientRepository;

    public List<Patient> getPatient(){
        return patientRepository.findAll();
    }

    public void addPatient(Patient patient){
        patientRepository.save(patient);
    }

    public void updatePatient(Integer id, @Valid Patient patient){
        Patient oldPatient = patientRepository.findPatientById(id);
        if (oldPatient==null)
            throw new ApiException("wrong id");
        oldPatient.setName(patient.getName());
        oldPatient.setAge(patient.getAge());
        oldPatient.setGender(oldPatient.getGender());
        patientRepository.save(oldPatient);
    }

    public void deletePatient(Integer id){
        Patient patient = patientRepository.findPatientById(id);
        if (patient==null)
            throw new ApiException("wrong ID");
        patientRepository.delete(patient);

    }

    public Patient getPatientById(Integer id){
        Patient patient = patientRepository.findPatientById(id);
        if (patient==null)
            throw new ApiException("wrong ID");
        return patient;
    }

    public List<Patient> getAllByGender(String gender){
        return patientRepository.findByGenderContaining(gender);
    }



    public List<Patient> getPatientByDoctorId(Integer id){
        List<Patient> p= patientRepository.findAllByDoctorId(id);
        if(p.isEmpty()){
            throw new ApiException("wrong ID");
        }
        return  p ;
    }

}
