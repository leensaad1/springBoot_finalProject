package com.example.springboot_finalproject.Repository;

import com.example.springboot_finalproject.Model.Doctor;
import com.example.springboot_finalproject.Model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PatientRepository extends JpaRepository<Patient,Integer> {

    Patient findPatientById(Integer id);

    //List<Doctor> findDoctorByPatientId(Integer id);

    List<Patient> findByGenderContaining(String gender);

    List<Patient> findAllByDoctorId(Integer id);

}
