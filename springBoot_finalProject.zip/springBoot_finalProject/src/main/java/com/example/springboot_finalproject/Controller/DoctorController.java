package com.example.springboot_finalproject.Controller;

import com.example.springboot_finalproject.Dto.ApiResponse;
import com.example.springboot_finalproject.Model.Doctor;
import com.example.springboot_finalproject.Service.DoctorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/doctor")
@RequiredArgsConstructor
public class DoctorController {

    private final DoctorService doctorService;

    @GetMapping("/get")
    public ResponseEntity getDoctor(){
        List<Doctor> doctors = doctorService.getDoctor();
        return ResponseEntity.status(200).body(doctors);
    }

    @PostMapping ("/add")
    public ResponseEntity addDoctor(@RequestBody Doctor doctor){
        doctorService.addDoctor(doctor);
        return ResponseEntity.status(200).body(new ApiResponse("doctor added!"));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateDoctor(@PathVariable Integer id, @RequestBody @Valid Doctor doctor){
        doctorService.updateDoctor(id, doctor);
        return ResponseEntity.status(200).body(new ApiResponse("doctor updated!"));
    }

    @DeleteMapping("/delete/{id}")
    public String deleteDoctor(@PathVariable Integer id){
        doctorService.deleteDoctor(id);
        return "doctor deleted!";
    }
//
    @GetMapping("/byid/{id}")
    public ResponseEntity getDoctorById(@PathVariable Integer id){
        Doctor doctor = doctorService.getDoctorById(id);
        return ResponseEntity.status(200).body(doctor);
    }



}
