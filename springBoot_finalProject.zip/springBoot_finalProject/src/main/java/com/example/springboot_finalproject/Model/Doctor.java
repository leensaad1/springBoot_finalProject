package com.example.springboot_finalproject.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Doctor {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Integer id;

    @NotEmpty(message = "name can't be empty!")
    @Column (columnDefinition = "varchar(20) not null")
    private String name;

    @NotEmpty(message = "specialty can't be empty!")
    @Column (columnDefinition = "varchar(20) not null")
    private String specialty;

}
