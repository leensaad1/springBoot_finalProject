package com.example.springboot_finalproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFinalProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootFinalProjectApplication.class, args);
    }

}
