package com.example.springboot_finalproject.Service;


import com.example.springboot_finalproject.Exception.ApiException;
import com.example.springboot_finalproject.Model.Doctor;
import com.example.springboot_finalproject.Model.Patient;
import com.example.springboot_finalproject.Repository.DoctorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DoctorService {

    private final DoctorRepository doctorRepository;

    public List<Doctor> getDoctor(){
        return doctorRepository.findAll();
    }

    public void addDoctor(Doctor doctor){
        doctorRepository.save(doctor);
    }

    public void updateDoctor(Integer id, Doctor doctor){
        Doctor oldDoctor = doctorRepository.findDoctorById(id);
        if (oldDoctor==null){
            throw new ApiException("wrong id");}
        oldDoctor.setName(doctor.getName());
        oldDoctor.setSpecialty(doctor.getSpecialty());
        doctorRepository.save(oldDoctor);
    }

    public void deleteDoctor(Integer id){
        Doctor doctor = doctorRepository.findDoctorById(id);
        if (doctor==null)
            throw new ApiException("wrong ID");
        doctorRepository.delete(doctor);
    }

    public Doctor getDoctorById(Integer id){
        Doctor doctor = doctorRepository.findDoctorById(id);
        if (doctor==null)
            throw new ApiException("wrong ID");
        return doctor;
    }



}
