package com.example.springboot_finalproject.Repository;

import com.example.springboot_finalproject.Model.Prescription;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PrescriptionRepository extends JpaRepository<Prescription, Integer> {

    Prescription findPrescriptionById(Integer id);

    List<Prescription> findAllByPatientName(String PatientName);

}
