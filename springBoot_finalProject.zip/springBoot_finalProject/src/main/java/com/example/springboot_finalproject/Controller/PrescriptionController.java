package com.example.springboot_finalproject.Controller;


import com.example.springboot_finalproject.Dto.ApiResponse;
import com.example.springboot_finalproject.Model.Patient;
import com.example.springboot_finalproject.Model.Prescription;
import com.example.springboot_finalproject.Service.PatientService;
import com.example.springboot_finalproject.Service.PrescriptionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/pres")
@RequiredArgsConstructor
public class PrescriptionController {

    final private PrescriptionService prescriptionService;

    @GetMapping("/get")
    public ResponseEntity getPrescription(){
        List<Prescription> prescriptions = prescriptionService.getPrescription();
        return ResponseEntity.status(200).body(prescriptions);
    }

    @PostMapping("/add")
    public ResponseEntity addPrescription(@RequestBody Prescription prescription){
        prescriptionService.addPrescription(prescription);
        return ResponseEntity.status(200).body(new ApiResponse("Prescription added!"));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updatePrescription(@PathVariable Integer id, @RequestBody @Valid Prescription prescription){
        prescriptionService.updatePrescription(id, prescription);
        return ResponseEntity.status(200).body(new ApiResponse("Prescription updated!"));
    }

    @DeleteMapping("/delete/{id}")
    public String deletePrescription(@PathVariable Integer id){
        prescriptionService.deletePrescription(id);
        return "Prescription deleted!";
    }
/////
    @GetMapping("/by/patient/{name}")
    public ResponseEntity getPrescriptionByPatientName(@PathVariable String name){
        return ResponseEntity.status(200).body(prescriptionService.findByPatientName(name));
    }

}
