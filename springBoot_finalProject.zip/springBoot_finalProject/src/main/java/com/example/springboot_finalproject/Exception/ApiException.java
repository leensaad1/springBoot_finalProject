package com.example.springboot_finalproject.Exception;

public class ApiException extends RuntimeException {

    public ApiException (String msg){
        super(msg);
    }

}
