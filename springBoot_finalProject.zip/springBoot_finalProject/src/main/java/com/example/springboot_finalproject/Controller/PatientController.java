package com.example.springboot_finalproject.Controller;

import com.example.springboot_finalproject.Dto.ApiResponse;
import com.example.springboot_finalproject.Model.Doctor;
import com.example.springboot_finalproject.Model.Patient;
import com.example.springboot_finalproject.Service.PatientService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/patient")
@RequiredArgsConstructor
public class PatientController {

    final private PatientService patientService;

    @GetMapping("/get")
    public ResponseEntity getPatient(){
        List<Patient> patients = patientService.getPatient();
        return ResponseEntity.status(200).body(patients);
    }

    @PostMapping("/add")
    public ResponseEntity addPatient(@RequestBody Patient patient){
        patientService.addPatient(patient);
        return ResponseEntity.status(200).body(new ApiResponse("patient added!"));
    }
//
    @PutMapping("/update/{id}")
    public ResponseEntity updatePatient(@PathVariable Integer id, @RequestBody @Valid Patient patient){
        patientService.updatePatient(id, patient);
        return ResponseEntity.status(200).body(new ApiResponse("patient updated!"));
    }

    @DeleteMapping("/delete/{id}")
    public String deletePatient(@PathVariable Integer id){
        patientService.deletePatient(id);
        return "patient deleted!";
    }
//
    @GetMapping("/byid/{id}")
    public ResponseEntity getPatientById(@PathVariable Integer id){
        Patient patient = patientService.getPatientById(id);
        return ResponseEntity.status(200).body(patient);
    }

    @GetMapping("/bygender/{gender}")
    public ResponseEntity getAllByGender(@PathVariable String gender){
        return ResponseEntity.status(200).body(patientService.getAllByGender(gender));
    }


        @GetMapping("/by/doctor/{id}")
    public ResponseEntity getPatientByDoctorId(@PathVariable Integer id){

        return ResponseEntity.status(200).body(patientService.getPatientByDoctorId(id));
    }

}
