package com.example.springboot_finalproject.Service;


import com.example.springboot_finalproject.Exception.ApiException;
import com.example.springboot_finalproject.Model.Patient;
import com.example.springboot_finalproject.Model.Prescription;
import com.example.springboot_finalproject.Repository.PatientRepository;
import com.example.springboot_finalproject.Repository.PrescriptionRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PrescriptionService {

    final private PrescriptionRepository prescriptionRepository;

    public List<Prescription> getPrescription(){
        return prescriptionRepository.findAll();
    }

    public void addPrescription(Prescription prescription){
        prescriptionRepository.save(prescription);
    }

    public void updatePrescription(Integer id, @Valid Prescription prescription){
        Prescription oldPrescription = prescriptionRepository.findPrescriptionById(id);
        if (oldPrescription==null)
            throw new ApiException("wrong id");
        oldPrescription.setMedicName(prescription.getMedicName());
        oldPrescription.setDescription(prescription.getDescription());
        prescriptionRepository.save(oldPrescription);
    }

    public void deletePrescription(Integer id){
        Prescription prescription = prescriptionRepository.findPrescriptionById(id);
        if (prescription==null)
            throw new ApiException("wrong ID");
        prescriptionRepository.delete(prescription);
    }


    public List<Prescription> findByPatientName(String name){
        List<Prescription> prescriptions = prescriptionRepository.findAllByPatientName(name);
        if (prescriptions.isEmpty())
            throw new ApiException("wrong name");
       return prescriptions;
    }

}
