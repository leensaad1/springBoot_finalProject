package com.example.springboot_finalproject.Repository;

import com.example.springboot_finalproject.Model.Doctor;
import com.example.springboot_finalproject.Model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DoctorRepository extends JpaRepository<Doctor,Integer> {

    Doctor findDoctorById(Integer id);



}
