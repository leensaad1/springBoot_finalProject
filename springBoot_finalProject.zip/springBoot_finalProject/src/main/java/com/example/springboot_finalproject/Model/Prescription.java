package com.example.springboot_finalproject.Model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Prescription {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Integer id;

    @NotEmpty(message = "medicine name can't be empty!")
    @Column(columnDefinition = "varchar(20) not null")
    private String medicName;

    @NotEmpty(message = "description can't be empty!")
    private String description;

    @NotEmpty(message = "patient name can't be empty!")
    private String patientName;

}
