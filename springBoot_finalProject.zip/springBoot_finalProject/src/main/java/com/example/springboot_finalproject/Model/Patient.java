package com.example.springboot_finalproject.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.PathVariable;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Patient {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Integer id;

    @NotEmpty(message = "name can't be empty!")
    @Column(columnDefinition = "varchar(20) not null")
    private String name;

    @NotNull(message = "age can't be null")
    private int age;

    @Column(columnDefinition = "varchar(3) not null check (gender='f' or gender='m')")
    //@Pattern(regexp = "('f'|'m')")
    private String gender;

    private Integer doctorId;

}
